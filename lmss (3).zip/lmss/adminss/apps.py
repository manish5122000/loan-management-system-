from django.apps import AppConfig


class AdminssConfig(AppConfig):
    name = 'adminss'
